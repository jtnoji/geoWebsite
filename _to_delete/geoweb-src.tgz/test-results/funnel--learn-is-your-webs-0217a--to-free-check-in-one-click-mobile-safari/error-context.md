# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/is-your-website-invisible-to-ai-crawlers/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/is-your-website-invisible-to-ai-crawlers/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/is-your-website-invisible-to-ai-crawlers/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - link "← All articles":
    - /url: /learn/
  - heading "Is your website invisible to AI crawlers?" [level=1]
  - paragraph:
    - time: 2026-07-21
  - paragraph: Many business websites are invisible to AI engines and their owners have no idea. Firewalls and CDN bot-protection settings silently serve challenge pages or errors to crawlers like GPTBot, ClaudeBot, and PerplexityBot. If those crawlers can't read your site, the engines answering your customers' questions are working from everyone's content but yours.
  - heading "How does a website end up blocking AI crawlers by accident?" [level=2]
  - paragraph: "Bot protection gets switched on for good reasons, like scrapers and attack traffic, and AI crawlers get caught in the same net. Since July 2025 it can also be the default: Cloudflare, which sits in front of roughly 20% of web traffic, blocks AI crawlers on newly added domains unless the owner allows them, and over a million sites had opted into blocking before that. Other culprits: \"bot fight\" or attack-challenge modes, aggressive firewall rules, and robots.txt files that disallow everything. Nobody notices, because the site looks normal in a human browser."
  - heading "How can I check if AI bots can read my site?" [level=2]
  - paragraph: Fetch your pages the way the bots do. Request them with the user agents of GPTBot, ClaudeBot, and PerplexityBot and look at what comes back. Real content with a 200 status means you're readable. A challenge page, CAPTCHA, 403, or empty shell means you're blocked. While you're there, check that your robots.txt allows these crawlers by name.
  - heading "Does JavaScript-heavy rendering cause the same problem?" [level=2]
  - paragraph: "It's a second, separate way to be invisible. Vercel and MERJ analyzed 500 million GPTBot fetches and found zero instances of JavaScript execution: the crawler downloads script files but never runs them, and the same goes for Claude's and Perplexity's crawlers. If your content only appears after scripts run, those crawlers see an empty page even when nothing is blocking them. Quick test: turn off JavaScript in your browser and reload your site. Whatever disappears is what the crawlers never saw."
  - heading "Should I just allow every bot then?" [level=2]
  - paragraph: Allow the crawlers of the engines you want naming you. For most businesses that's OpenAI, Anthropic, Google, and Perplexity, while keeping protection against genuinely abusive traffic. It's a scalpel, not a switch, and the first step is knowing where you stand instead of assuming.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/is-your-website-invisible-to-ai-crawlers/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```