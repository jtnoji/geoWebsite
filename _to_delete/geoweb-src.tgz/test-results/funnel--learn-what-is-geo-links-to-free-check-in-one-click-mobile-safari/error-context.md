# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/what-is-geo/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/what-is-geo/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/what-is-geo/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - link "← All articles":
    - /url: /learn/
  - heading "What is GEO (Generative Engine Optimization)?" [level=1]
  - paragraph:
    - time: 2026-07-21
  - paragraph: GEO, short for Generative Engine Optimization, is the practice of measuring and improving how often AI engines like ChatGPT, Google's AI answers, Gemini, and Perplexity mention your business when customers ask them questions. SEO optimized for a list of links. GEO deals with a written answer that names only a few businesses, and the job is being one of them.
  - heading "How is GEO different from SEO?" [level=2]
  - paragraph:
    - text: "SEO competes for position on a page with ten or more slots. GEO competes for a mention inside a paragraph that usually names two or three. The shortlist is measurably shorter: a"
    - link "Sterling Sky and Places Scout study":
      - /url: https://www.sterlingsky.ca/
    - text: across 322 markets counted 5,943 unique businesses in AI local answers against 18,330 in traditional map packs, roughly three times fewer winners. And more people are asking.
    - link "BrightLocal's 2026 survey":
      - /url: https://www.brightlocal.com/research/lcrs-ai-trust/
    - text: found 45% of U.S. consumers used AI tools to find local businesses last year, up from 6% the year before. The game is no longer "rank higher." It's "make the shortlist at all."
  - heading "What influences AI answers?" [level=2]
  - paragraph: "A mix of what the models learned in training and what they retrieve live: review sites, directories, press, and your own website. Three things come up in almost every audit we run. Can AI crawlers read your site? Do the sources the engines cite in your category know you exist? Does anything you've published answer the questions customers ask? None of it is exotic, and all of it is measurable."
  - heading "Can GEO be measured?" [level=2]
  - paragraph: Yes, but only with sampling. AI answers change from run to run, so a single query proves nothing. Real measurement asks the same customer questions repeatedly across engines and reports rates. "Named in 7 of 10 runs" is a measurement. A screenshot of one good answer is an anecdote.
  - heading "Can anyone guarantee a spot in AI answers?" [level=2]
  - paragraph: "No. Nobody controls what ChatGPT says, and anyone promising you a #1 spot in AI answers is selling something they can't deliver. What's honest and possible: measure where you stand, fix the things with evidence behind them, and measure again."
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/what-is-geo/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```