# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> / links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: / should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - / should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - text: AI visibility, measured
  - heading "When someone asks AI for a recommendation, does it say your name?" [level=1]
  - paragraph: ChatGPT, Google AI, Gemini, and Perplexity answer your customers directly, and each answer names only a few businesses. [Brand] measures whether you’re one of them and who gets named instead.
  - link "Get your free check ⟶":
    - /url: /free-check/
  - link "See a sample report":
    - /url: /sample-report/
  - text: chatgpt · “best b2b marketing agency for seed-stage startups” run 3/10
  - paragraph: For a seed-stage B2B startup, I’d look at Saltgrass Digital, Fathom & Reed, or Pinelock Marketing. All three have strong track records with early-stage B2B companies…
  - text: "Your business: not mentioned"
  - paragraph: 2 / 10 runs
  - paragraph: named on ChatGPT · competitor 8/10
  - figure "BrightLocal, 2026":
    - paragraph: 45%
    - blockquote: of U.S. consumers used AI tools to find local businesses last year, up from 6% the year before.
    - link "BrightLocal, 2026":
      - /url: https://www.brightlocal.com/research/lcrs-ai-trust/
  - figure "Sterling Sky / Places Scout, 322-market study":
    - paragraph: 3× fewer
    - blockquote: businesses appear in AI answers than in traditional search results. The shortlist got smaller.
    - link "Sterling Sky / Places Scout, 322-market study":
      - /url: https://www.sterlingsky.ca/
  - figure "Whitespark, 2025":
    - paragraph: 2 of 3
    - blockquote: local-business searches now show an AI-generated answer above the results.
    - link "Whitespark, 2025":
      - /url: https://whitespark.ca/blog/case-study-the-prevalence-of-ai-overviews-in-local-search/
  - text: What we do
  - heading "We measure it. Properly." [level=2]
  - paragraph: We run your customers’ real questions across ChatGPT, Google’s AI answers, Gemini, and Perplexity, multiple times each, because the answers change run to run. Then we grade every one. You get numbers, not vibes.
  - term: Mention rate
  - definition: Named in 7 of 10 runs. Rates, not one-off screenshots.
  - term: Share of voice
  - definition: You vs. the competitors named instead of you.
  - term: Accuracy
  - definition: What AI says about you, checked against the facts.
  - term: Sources
  - definition: The sites AI cites when it builds the answer.
  - text: mention rate by engine · sample 10 runs/engine You Competitor ChatGPT 2/10 8/10 Google AI 0/10 6/10 Perplexity 3/10 7/10 Gemini 1/10 5/10 n=32 queries · illustrative example · not a real client
  - paragraph:
    - link "see the full sample report →":
      - /url: /sample-report/
  - text: How it works
  - heading "Three steps, no theater" [level=2]
  - link "Full methodology →":
    - /url: /how-it-works/
  - list:
    - listitem:
      - text: "01"
      - heading "We ask" [level=3]
      - paragraph: Real customer questions, run across every major AI engine, multiple times each.
    - listitem:
      - text: "02"
      - heading "We judge" [level=3]
      - paragraph: Every answer graded for presence, prominence, and accuracy against a fact sheet you approve.
    - listitem:
      - text: "03"
      - heading "You get a roadmap" [level=3]
      - paragraph: Your numbers, your gaps, and a fix list ordered by what moves AI answers. We can implement it for you and measure again.
  - heading "The shortlist got smaller" [level=2]
  - paragraph:
    - text: Ask Google or ChatGPT “which marketing agency should I hire” and you don’t get ten blue links. You get a paragraph that names two or three options. If you’re not in it, you’re not in the conversation. And you never find out, because everyone’s answer is different and nobody screenshots the AI that
    - emphasis: didn’t
    - text: mention them.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: / should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```