# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /how-it-works/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /how-it-works/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /how-it-works/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - text: Methodology · v2.1 · May 2026
  - heading "Measurement you can actually inspect." [level=1]
  - paragraph: "The full protocol: what we run, how often, and how every answer is judged. Public, because measurement you can’t inspect is just marketing."
  - text: n=32 queries engines=4 runs=10× each judged vs fact sheet The pipeline
  - heading "Five stages to the report, then the work" [level=2]
  - text: "01 Query set Real customer questions, locked per cycle. \"how much should a startup spend on a marketing agency\" 02 Four engines Chat models + live-search surfaces. chatgpt · google ai · gemini · perplexity 03 Ten runs Answers change run to run. ●●●●●●●●●● → 4/10 mention rate 04 Judged Graded against ground truth. presence · prominence · accuracy 05 Reported Rates, gaps, roadmap. losing queries → who's named instead → why 06 Implemented Ongoing tier: we make the fixes, then re-run. fix → re-run → before / after"
  - complementary:
    - navigation "Sections":
      - link "§1 What we ask":
        - /url: "#s1"
      - link "§2 How we sample":
        - /url: "#s2"
      - link "§3 How we judge":
        - /url: "#s3"
      - link "§4 What you get":
        - /url: "#s4"
      - link "§5 What we won't promise":
        - /url: "#s5"
  - text: §1 · The query set
  - heading "The questions your customers actually ask" [level=2]
  - paragraph: "Real phrasings from across the funnel: cost, comparison, \"is this agency worth it.\" Locked per cycle, so every before and after is apples to apples."
  - text: query set · b2b marketing agency v1 · locked "best b2b marketing agency for seed-stage startups" CATEGORY "how much should a startup spend on a marketing agency" COST "marketing agency vs first marketing hire" COMPARE "is [agency] worth it for a seed-stage company" BRAND §2 · Sampling
  - heading "Ten runs, not one screenshot" [level=2]
  - paragraph:
    - text: AI answers change between runs, so a single fetch is a coin flip. We run every query 10× per engine and report the rate. A single-run "AI rank" is noise.
    - superscript: "1"
  - paragraph: 1. Four of five URLs change between repeat runs of the same AI query; explicit-city queries are about twice as stable. SE Ranking AI Mode volatility test, 2025.
  - text: "sampling: “best b2b marketing agency for seed-stage startups” 10 runs/engine You Competitor ChatGPT 2/10 8/10 Google AI 0/10 6/10 Perplexity 3/10 7/10 Gemini 1/10 5/10 illustrative example · not a real client §3 · Judging"
  - heading "Every answer graded against ground truth" [level=2]
  - paragraph: "A mention isn't enough. Each answer is judged against a fact sheet you approve: present? prominent? accurate? If AI says you only run paid ads when you run full-funnel, that's a finding, not a blind spot."
  - text: "judge verdict · run 7/10 · chatgpt fact sheet v3 presence Mentioned: 2nd of 3 named prominence Secondary: not the lead recommendation accuracy 1 error: says they only run paid ads; they run full-funnel missing_or_invented_feature · HIGH §4 · The report and the work"
  - heading "Numbers first, then the roadmap, then the work" [level=2]
  - paragraph: Rates by engine and question type, the queries you're losing, who's named instead, and a fix list ranked by what the evidence says moves answers. On the ongoing tier we implement that list and run the whole protocol again, so every change is measured rather than assumed.
  - text: Mention rates per engine · per question type Losing queries where a rival is named, not you Source map the sites AI cites, and where you're missing Roadmap prioritized, evidence-ranked fixes §5 · The fine print, up front
  - heading "What we won't promise" [level=2]
  - complementary:
    - paragraph:
      - text: "Nobody controls what ChatGPT says. Anyone who guarantees you a #1 spot in AI answers is selling something they can't deliver."
      - emphasis: What we deliver is the work, and honest measurement of what it changed
      - text: ": where you stand, which fixes the evidence supports, and what moved after we made them. Our reports show sampled rates, because that's the only claim we can stand behind."
    - paragraph: No guarantees Sampled rates · No theater
  - heading "See the protocol run on your business." [level=2]
  - paragraph: "The free check is a small version of exactly this: real queries, real engines, real answers."
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /how-it-works/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```