# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /pricing/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /pricing/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /pricing/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - heading "Pricing" [level=1]
  - paragraph: Three tiers. Every one reports sampled rates with named sources. None of them, at any price, promises rankings.
  - text: "01"
  - heading "Free Visibility Check" [level=2]
  - paragraph: $0
  - paragraph: The short report. Where you stand on the big three engines, and who's named instead of you.
  - paragraph
  - link "Get started":
    - /url: /free-check/
  - text: 02 · most popular
  - heading "Full AI Visibility Audit" [level=2]
  - paragraph: "[$X] one-time"
  - paragraph: Full query set across all engines, sampled runs, judged answers, accuracy findings, and a site and off-site audit. You get a report and a walkthrough call.
  - paragraph
  - link "Book a call":
    - /url: /contact/
  - text: "03"
  - heading "Ongoing GEO" [level=2]
  - paragraph: "[$X]/mo"
  - paragraph: "We work the roadmap ourselves: implement the fixes on your site and off it, then re-run the audit so you can see what each change did. Before and after mention rates, new competitors, new sources."
  - paragraph: Now booking our first implementation clients.
  - link "Book a call":
    - /url: /contact/
  - heading "Do you do the fixes too?" [level=2]
  - paragraph: Yes, on the ongoing tier. We implement the roadmap on your site and off it, then re-measure so you can see what each change did. It's the newest part of what we do and we're booking our first implementation clients now. If you'd rather your own web team execute, every fix is written so a competent developer can pick it up.
  - heading "How long until AI answers change?" [level=2]
  - paragraph: Weeks to months, and it varies by engine and by fix. We measure the change rather than promise it, which is why the ongoing tier pairs the work with a re-run of the audit.
  - heading "What do you need from me?" [level=2]
  - paragraph: A fact sheet about your business (we send a template) and 30 minutes to approve it. Everything else runs on our side.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /pricing/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```