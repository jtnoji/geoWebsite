# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /privacy/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /privacy/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /privacy/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - heading "Privacy" [level=1]
  - paragraph: "[Brand] runs AI visibility checks from Berkeley, CA. The only personal information we hold is what you send through the free check. This page says exactly what that is, in the same plain language as the rest of the site."
  - paragraph: In effect since 25 July 2026
  - heading "What does the free check collect?" [level=2]
  - paragraph: "Five things you type: your business name, your website, your city or service area, a short description of what you do, and your email address. Nothing else is required."
  - heading "Is anything collected that I did not type?" [level=2]
  - paragraph: Two things, both about how you arrived. If you followed a link with a campaign code in it, we store that code. We also store the address of the page that referred you, which your browser sends to every site you visit.
  - heading "What about the phone number you ask for afterwards?" [level=2]
  - paragraph: That is optional and it is only asked after your check is already submitted. If you leave a number, Josh calls you once, when your report is ready. We do not text it, add it to a dialler, or use it for anything else.
  - heading "Why do you collect it?" [level=2]
  - paragraph: To run your check and email you the report. Your website and description tell us which questions to ask the AI engines, and your city tells us where to ask them from.
  - heading "Does this site use cookies or trackers?" [level=2]
  - paragraph: No cookies, and nothing that follows you from site to site. We count page views with Vercel Web Analytics, which stores no identifier on your device and builds no profile of you. Its script and our fonts are both served from our own domain, so loading a page contacts nobody else.
  - heading "Who else can see my details?" [level=2]
  - paragraph: "Two companies, both acting as our infrastructure: Vercel hosts the site and counts page views, and Supabase stores your submission. We do not sell your details, share them with advertisers, or add you to a marketing list."
  - heading "How long do you keep it?" [level=2]
  - paragraph: We keep your submission while you are a live prospect or a client. If you never become either, we delete it after 12 months.
  - heading "How do I get my data deleted?" [level=2]
  - paragraph: Email hello@example.com and ask. We delete it within 30 days and reply to confirm. You do not need an account and you do not need to explain why.
  - heading "What do you do with my website address?" [level=2]
  - paragraph: We fetch your public pages the way an AI crawler would, and we ask public AI engines questions about your business. We only ever look at what is already publicly visible.
  - heading "Questions, or a request?" [level=2]
  - paragraph:
    - text: Email
    - link "hello@example.com":
      - /url: mailto:hello@example.com
    - text: . If we change this policy, we change the date above and the page history is public in our repository.
  - link "Contact us":
    - /url: /contact/
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /privacy/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```