# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /sample-report/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /sample-report/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /sample-report/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - heading "This is what you actually get." [level=1]
  - paragraph: Below is a teaser for a fictional B2B marketing agency, in the exact format a client gets, with notes on how to read each section. The numbers are modeled on real audit runs. We’ll publish a real anonymized client report here as soon as one is cleared.
  - text: "chatgpt: “best b2b marketing agency for seed-stage startups” run 3/10"
  - paragraph: “For a seed-stage B2B startup, well-regarded agencies include Saltgrass Digital and Fathom & Reed…”
  - paragraph: The client was not mentioned.
  - paragraph: Every report opens with verbatim AI answers. The bold names are who got mentioned. The client’s absence is the finding.
  - text: mention rate · “best b2b marketing agency for seed-stage startups” 10 runs/engine You Competitor ChatGPT 2/10 8/10 Google AI 0/10 6/10 Perplexity 3/10 7/10 Gemini 1/10 5/10 illustrative example · not a real client
  - paragraph: Rates, not ranks. Each question runs ten times per engine, because a single fetch is a coin flip. “2 of 10 runs on ChatGPT, 0 of 10 on Google AI” is something you can re-run next month and compare.
  - text: cited-sources checklist site + off-site
  - list:
    - listitem: AI crawlers can read your site Blocked by firewall
    - listitem: Listed on the sources AI cites 2 of 6 best-agency lists
    - listitem: Content readable without JavaScript Yes
  - paragraph: "The cited-sources checklist: which websites the engines leaned on, and whether you exist on them."
  - heading "The prioritized fix list" [level=2]
  - paragraph: The full audit closes with fixes ordered by what moves AI answers. Each one ties back to a finding in the data.
  - list:
    - listitem:
      - text: "01"
      - paragraph: Unblock AI crawlers at the firewall
      - paragraph: GPTBot and PerplexityBot were getting challenge pages, so the site is invisible to the engines we measure.
    - listitem:
      - text: "02"
      - paragraph: Get listed on the 4 missing directories AI cites
      - paragraph: The engines cited the same 6 sources across runs; the client appears on 2 of them.
    - listitem:
      - text: "03"
      - paragraph: Publish answer-first service pages for the 3 losing queries
      - paragraph: Competitors' pages were quoted verbatim in the answers. The client had no page on those questions.
  - heading "Want yours?" [level=2]
  - paragraph: The free check takes one minute. Report in your inbox within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /sample-report/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```