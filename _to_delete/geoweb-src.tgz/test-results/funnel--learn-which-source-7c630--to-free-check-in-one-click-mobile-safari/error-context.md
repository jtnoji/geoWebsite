# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/which-sources-do-ai-engines-cite/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/which-sources-do-ai-engines-cite/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/which-sources-do-ai-engines-cite/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - link "← All articles":
    - /url: /learn/
  - heading "Which sources do AI engines actually cite?" [level=1]
  - paragraph:
    - time: 2026-07-21
  - paragraph: "For any given category and city, AI engines cite a surprisingly small and consistent set of sources: major review platforms, a couple of category-specific directories, local press, and business pages that answer questions directly. Which ones varies by category, which is why it has to be measured rather than assumed."
  - heading "How dominant are third-party sources?" [level=2]
  - paragraph: Very. Foundation Marketing and AirOps found only about 10% of citations across millions of AI answers pointed to brand-owned domains. For local services, Yelp alone earned 3.4 times more AI citations than the next closest source in their analysis of over 28 million answers. For B2B questions, Reddit led at 21%, with YouTube and LinkedIn at 13% each. Your website matters, but the sources talking about you usually matter more.
  - heading "Do all AI engines cite the same sources?" [level=2]
  - paragraph: No. Perplexity shows citations openly on nearly every answer. Google's AI answers lean on its own index and business profiles. ChatGPT mixes what its model learned in training with live web results. The overlap is partial, so doing well on the sources one engine trusts doesn't mean another engine sees you.
  - heading "How do I find out which sources matter in my category?" [level=2]
  - paragraph: "Run the questions your customers ask, repeatedly, and record the citations. After enough runs the pattern is obvious: the same handful of domains keeps appearing for your category and area. That handful is your off-site to-do list, and it beats a generic \"get listed everywhere\" checklist."
  - heading "What do I do with the list once I have it?" [level=2]
  - paragraph: Check each cited source for three things. Are you there? Is your information accurate and consistent with your website? Is your entry substantial enough to be quoted? Two or three solid entries on the sources your engines lean on beat fifty thin listings nobody cites.
  - heading "Does my own website count as a source?" [level=2]
  - paragraph: Yes. Engines quote business websites directly when a page cleanly answers the question asked. A page that states what you do, where, for whom, and at what price range, in plain language near the top, is quotable. A buried answer might as well not exist.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/which-sources-do-ai-engines-cite/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```