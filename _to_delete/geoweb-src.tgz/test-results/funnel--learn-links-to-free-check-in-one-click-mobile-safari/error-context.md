# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - heading "Learn" [level=1]
  - paragraph: Plain answers to the questions business owners ask about AI search. Each article opens with the answer.
  - list:
    - listitem:
      - 'link "Why doesn''t ChatGPT mention my business? The usual reasons: AI crawlers cannot read your site, the sources AI cites do not know you, or your content never answers what customers ask. Read the answer →"':
        - /url: /learn/why-doesnt-chatgpt-mention-my-business/
        - heading "Why doesn't ChatGPT mention my business?" [level=2]
        - paragraph: "The usual reasons: AI crawlers cannot read your site, the sources AI cites do not know you, or your content never answers what customers ask."
        - text: Read the answer →
    - listitem:
      - 'link "Which sources do AI engines actually cite? AI engines repeatedly cite a small, consistent set of sources per category: review platforms, directories, and pages that answer questions directly. Read the answer →"':
        - /url: /learn/which-sources-do-ai-engines-cite/
        - heading "Which sources do AI engines actually cite?" [level=2]
        - paragraph: "AI engines repeatedly cite a small, consistent set of sources per category: review platforms, directories, and pages that answer questions directly."
        - text: Read the answer →
    - listitem:
      - link "What is GEO (Generative Engine Optimization)? GEO is the practice of measuring and improving how often AI engines like ChatGPT, Google AI, and Perplexity mention and recommend your business. Read the answer →":
        - /url: /learn/what-is-geo/
        - heading "What is GEO (Generative Engine Optimization)?" [level=2]
        - paragraph: GEO is the practice of measuring and improving how often AI engines like ChatGPT, Google AI, and Perplexity mention and recommend your business.
        - text: Read the answer →
    - listitem:
      - link "Is your website invisible to AI crawlers? Many websites block AI crawlers without knowing it. Firewalls and CDN bot protection silently serve challenge pages to GPTBot and PerplexityBot. Read the answer →":
        - /url: /learn/is-your-website-invisible-to-ai-crawlers/
        - heading "Is your website invisible to AI crawlers?" [level=2]
        - paragraph: Many websites block AI crawlers without knowing it. Firewalls and CDN bot protection silently serve challenge pages to GPTBot and PerplexityBot.
        - text: Read the answer →
    - listitem:
      - 'link "AI search vs. SEO: what actually changed? The answer replaced the list: AI search names 2 or 3 businesses per answer, answers change run to run, and accuracy is now a visibility problem. Read the answer →"':
        - /url: /learn/ai-search-vs-traditional-seo/
        - 'heading "AI search vs. SEO: what actually changed?" [level=2]'
        - paragraph: "The answer replaced the list: AI search names 2 or 3 businesses per answer, answers change run to run, and accuracy is now a visibility problem."
        - text: Read the answer →
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```