# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/ai-search-vs-traditional-seo/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/ai-search-vs-traditional-seo/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/ai-search-vs-traditional-seo/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - link "← All articles":
    - /url: /learn/
  - 'heading "AI search vs. SEO: what actually changed?" [level=1]'
  - paragraph:
    - time: 2026-07-21
  - paragraph: "The core change: the answer replaced the list. Traditional search gave your customer ten links and let them choose. AI search hands them a written answer naming two or three businesses. Fewer winners per query, no page two, and the result changes from one run to the next. That changes how visibility works and how you measure it."
  - heading "Is SEO dead, then?" [level=2]
  - paragraph:
    - text: "No. Most of what made sites rank still feeds the engines: crawlable pages, real content, consistent business information, presence on trusted sources. What died is the measurement model. A rank is a stable position on a page. An AI answer is a sample from a distribution. And this isn't fringe behavior:"
    - link "Whitespark's 2025 study":
      - /url: https://whitespark.ca/blog/case-study-the-prevalence-of-ai-overviews-in-local-search/
    - text: found Google shows an AI Overview on 68% of local-business searches and 92% of informational ones.
  - heading "What matters more in AI search than it did in SEO?" [level=2]
  - paragraph: "Three things. Being on the shortlist of sources engines cite in your category beats accumulating links broadly. Answering real customer questions beats keyword coverage, because engines quote pages that answer plainly. And accuracy is now a visibility issue: an engine can name you and get your prices or services wrong, which a blue link could never do."
  - heading "How do I measure visibility when every answer is different?" [level=2]
  - paragraph:
    - text: By sampling.
    - link "SE Ranking's 2025 test":
      - /url: https://seranking.com/blog/ai-mode-volatility-test/
    - text: ran 5,000 local queries repeatedly and found four out of five cited URLs change between runs of the same query. So run the same customer questions many times per engine and report rates. "Named in 7 of 10 runs" is a number you can track. A single-fetch "AI rank" is a coin flip dressed up as data.
  - heading "What should a business do differently this year?" [level=2]
  - paragraph: Four things, in order. Check that AI crawlers can read your site. Find out which sources your engines cite, and make sure those sources know you. Publish pages that answer your customers' questions in the first sentence. Then measure before and after every change. The businesses that win here treat visibility as something you measure, not something you guess at.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/ai-search-vs-traditional-seo/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```