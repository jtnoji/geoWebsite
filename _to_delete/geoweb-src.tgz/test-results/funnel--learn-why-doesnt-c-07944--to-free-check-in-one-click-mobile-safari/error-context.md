# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /learn/why-doesnt-chatgpt-mention-my-business/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /learn/why-doesnt-chatgpt-mention-my-business/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /learn/why-doesnt-chatgpt-mention-my-business/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - link "← All articles":
    - /url: /learn/
  - heading "Why doesn't ChatGPT mention my business?" [level=1]
  - paragraph:
    - time: 2026-07-21
  - paragraph: "ChatGPT usually omits a business for one of three measurable reasons: its crawlers can't read your website, the sources it leans on don't list you, or nothing you've published answers the questions customers ask. Each one shows up clearly in an audit."
  - heading "Does ChatGPT even know my business exists?" [level=2]
  - paragraph: "Maybe not. AI engines learn about businesses from training data and from live retrieval: review platforms, directories, press, and your own site. A thin web presence means you're invisible to the systems writing the answers. Blocking can also happen without you doing anything. Cloudflare, which handles roughly a fifth of web traffic, started blocking AI crawlers by default on newly added domains in July 2025, so plenty of sites are walled off and their owners have no idea."
  - heading "Why does ChatGPT recommend my competitors instead?" [level=2]
  - paragraph: Because the sources it cites mention them more often, or more recently. In Foundation Marketing and AirOps' analysis of millions of AI answers, the brand's own website didn't appear at all in 68% of answers about it, and roughly nine in ten citations went to third-party sources. When an engine answers "best marketing agency for startups," it pulls from pages it trusts in that category, and the competitors who show up across those pages get named. The fix starts with knowing which sources the engine cited, which you measure rather than guess.
  - heading "Could ChatGPT be wrong about my business?" [level=2]
  - paragraph: Yes, and it's the overlooked half of the problem. An engine can mention you and still get your prices, hours, or services wrong, which is often worse than absence. Any serious visibility check grades accuracy, not just presence.
  - heading "What should I do first?" [level=2]
  - paragraph: Measure before you fix. Run the same customer questions repeatedly across engines and record when you're named, who's named instead, and which sources were cited. That turns "ChatGPT ignores me" from a frustration into a to-do list with an order.
  - heading "Find out what AI says about you. Free." [level=2]
  - paragraph: Takes one minute. We'll email your report within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /learn/why-doesnt-chatgpt-mention-my-business/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```