# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: funnel.spec.ts >> /our-score/ links to /free-check/ in one click
- Location: tests/funnel.spec.ts:10:7

# Error details

```
Error: /our-score/ should have a visible link to /free-check/

expect(locator).toBeVisible() failed

Locator:  locator('a[href*="/free-check"]').first()
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - /our-score/ should have a visible link to /free-check/ with timeout 5000ms
  - waiting for locator('a[href*="/free-check"]').first()
    14 × locator resolved to <a href="/free-check/" class="btn-pill px-[22px] py-[13px] text-[12.5px] tracking-[0.12em]">…</a>
       - unexpected value "hidden"

```

```yaml
- banner:
  - link "[Brand]":
    - /url: /
  - link "Free check ⟶":
    - /url: /free-check/
  - button "Open menu"
- main:
  - heading "We ran our own audit on this website. Here’s the report." [level=1]
  - paragraph: "A company selling AI visibility audits should pass its own. Below are the Cat 1–6 results for this site: same rubric, same checks, published and dated. Mention-rate tracking for [Brand] queries starts at launch and gets published here too."
  - paragraph: "Last audit: Pending first deploy"
  - table:
    - rowgroup:
      - row "Category What we check Result":
        - columnheader "Category"
        - columnheader "What we check"
        - columnheader "Result"
    - rowgroup:
      - 'row "Cat 1: Bot access GPTBot, ClaudeBot, PerplexityBot, Google-Extended fetch real pages (no challenge walls) robots.txt explicitly allows every major AI crawler; Vercel challenge mode off. Pass"':
        - 'cell "Cat 1: Bot access"'
        - cell "GPTBot, ClaudeBot, PerplexityBot, Google-Extended fetch real pages (no challenge walls) robots.txt explicitly allows every major AI crawler; Vercel challenge mode off."
        - cell "Pass"
      - 'row "Cat 2: Rendering Every word of copy and all schema present with JavaScript disabled The site is a pure static export, so there is no client-rendered content to miss. Pass"':
        - 'cell "Cat 2: Rendering"'
        - cell "Every word of copy and all schema present with JavaScript disabled The site is a pure static export, so there is no client-rendered content to miss."
        - cell "Pass"
      - 'row "Cat 3: Content structure Question-form headings with standalone, quotable first-sentence answers Enforced as a copy rule across /how-it-works, /pricing FAQ, and /learn. Pass"':
        - 'cell "Cat 3: Content structure"'
        - cell "Question-form headings with standalone, quotable first-sentence answers Enforced as a copy rule across /how-it-works, /pricing FAQ, and /learn."
        - cell "Pass"
      - 'row "Cat 4: Local presence Consistent NAP on every page; founders named with profiles NAP renders site-wide from one source file. The business name and directory listings land with the brand decision. Partial"':
        - 'cell "Cat 4: Local presence"'
        - cell "Consistent NAP on every page; founders named with profiles NAP renders site-wide from one source file. The business name and directory listings land with the brand decision."
        - cell "Partial"
      - 'row "Cat 5: Structured data Organization, ProfessionalService, FAQPage, Service, Person schema, all matching visible text Schema is generated from the same data structures that render the visible copy, so it cannot drift. Pass"':
        - 'cell "Cat 5: Structured data"'
        - cell "Organization, ProfessionalService, FAQPage, Service, Person schema, all matching visible text Schema is generated from the same data structures that render the visible copy, so it cannot drift."
        - cell "Pass"
      - 'row "Cat 6: Hygiene sitemap.xml, canonical URLs, unique titles and descriptions, OG tags Generated at build time; verified by the CI test suite on every deploy. Pass"':
        - 'cell "Cat 6: Hygiene"'
        - cell "sitemap.xml, canonical URLs, unique titles and descriptions, OG tags Generated at build time; verified by the CI test suite on every deploy."
        - cell "Pass"
  - heading "This is the exact report you'd get." [level=2]
  - paragraph: See where your own site stands. Free, in your inbox within 1–2 business days.
  - link "Get your free visibility check":
    - /url: /free-check/
  - paragraph: No call required · No obligation
- contentinfo:
  - paragraph:
    - text: "[Brand] · Berkeley, CA ·"
    - link "hello@example.com":
      - /url: mailto:hello@example.com
  - paragraph: We measure whether AI engines mention your business, then do the work the measurements point to. Sampled rates, named sources, no guarantees.
  - navigation "Footer":
    - paragraph: Pages
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Free AI Visibility Check":
          - /url: /free-check/
      - listitem:
        - link "Sample report":
          - /url: /sample-report/
      - listitem:
        - link "How it works":
          - /url: /how-it-works/
      - listitem:
        - link "Pricing":
          - /url: /pricing/
      - listitem:
        - link "Learn":
          - /url: /learn/
      - listitem:
        - link "About":
          - /url: /about/
      - listitem:
        - link "Contact":
          - /url: /contact/
      - listitem:
        - link "Our score":
          - /url: /our-score/
      - listitem:
        - link "Privacy":
          - /url: /privacy/
  - paragraph: Founders
  - list:
    - listitem:
      - link "Abhi Jinka on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/abhinavjinka/
    - listitem:
      - link "Josh Noji on LinkedIn ↗":
        - /url: https://www.linkedin.com/in/joshuanoji/
  - paragraph: © 2026 [Brand]. We report measurements, not promises.
- link "Get your free AI check":
  - /url: /free-check/
- alert
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { PAGES } from "./pages";
  3  | 
  4  | /**
  5  |  * The funnel rule (website-plan.md §1): every page reaches /free-check in
  6  |  * ≤1 click, and the form submits through to the confirmation state.
  7  |  */
  8  | 
  9  | for (const page of PAGES) {
  10 |   test(`${page.path} links to /free-check/ in one click`, async ({ page: pw }) => {
  11 |     await pw.goto(page.path);
  12 |     const links = pw.locator('a[href*="/free-check"]');
  13 |     await expect(
  14 |       links.first(),
  15 |       `${page.path} should have a visible link to /free-check/`
> 16 |     ).toBeVisible();
     |       ^ Error: /our-score/ should have a visible link to /free-check/
  17 |   });
  18 | }
  19 | 
  20 | test("free-check form fills, submits, and confirms", async ({ page }) => {
  21 |   // Stub the Supabase insert so CI runs never write real rows to the leads
  22 |   // queue; the form's real submit path is still exercised.
  23 |   await page.route("**/rest/v1/leads", (route) =>
  24 |     route.fulfill({ status: 201, body: "" })
  25 |   );
  26 |   await page.goto("/free-check/");
  27 | 
  28 |   await page.fill("#business", "Bluequarry Growth (test)");
  29 |   await page.fill("#website", "https://bluequarry-test.example.com");
  30 |   await page.fill("#area", "Oakland, CA");
  31 |   await page.fill("#description", "B2B marketing for seed-stage startups.");
  32 |   await page.fill("#email", "founder@bluequarry-test.example.com");
  33 |   await page.getByRole("button", { name: "Run my free check" }).click();
  34 | 
  35 |   const confirmation = page.getByTestId("free-check-confirmation");
  36 |   await expect(confirmation).toBeVisible();
  37 |   await expect(confirmation).toContainText("running your check");
  38 |   await expect(confirmation).toContainText("1–2 business days");
  39 | });
  40 | 
```